﻿namespace ChapterFourTutorial4_1
{
    partial class TestScoreAverage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.test1ScoreLB = new System.Windows.Forms.Label();
            this.TestScoreGB = new System.Windows.Forms.GroupBox();
            this.test2ScoreLB = new System.Windows.Forms.Label();
            this.test3ScoreLB = new System.Windows.Forms.Label();
            this.averageLB = new System.Windows.Forms.Label();
            this.outAverageLabel = new System.Windows.Forms.Label();
            this.test1TextBox = new System.Windows.Forms.TextBox();
            this.test2TextBox = new System.Windows.Forms.TextBox();
            this.test3TextBox = new System.Windows.Forms.TextBox();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.TestScoreGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // test1ScoreLB
            // 
            this.test1ScoreLB.AutoSize = true;
            this.test1ScoreLB.Location = new System.Drawing.Point(22, 42);
            this.test1ScoreLB.Name = "test1ScoreLB";
            this.test1ScoreLB.Size = new System.Drawing.Size(75, 13);
            this.test1ScoreLB.TabIndex = 4;
            this.test1ScoreLB.Text = "Test Score #1";
            // 
            // TestScoreGB
            // 
            this.TestScoreGB.Controls.Add(this.test3TextBox);
            this.TestScoreGB.Controls.Add(this.test2TextBox);
            this.TestScoreGB.Controls.Add(this.test1TextBox);
            this.TestScoreGB.Controls.Add(this.outAverageLabel);
            this.TestScoreGB.Controls.Add(this.averageLB);
            this.TestScoreGB.Controls.Add(this.test3ScoreLB);
            this.TestScoreGB.Controls.Add(this.test2ScoreLB);
            this.TestScoreGB.Controls.Add(this.test1ScoreLB);
            this.TestScoreGB.Location = new System.Drawing.Point(30, 30);
            this.TestScoreGB.Name = "TestScoreGB";
            this.TestScoreGB.Size = new System.Drawing.Size(325, 222);
            this.TestScoreGB.TabIndex = 1;
            this.TestScoreGB.TabStop = false;
            this.TestScoreGB.Text = "Enter Three Test Scores";
            // 
            // test2ScoreLB
            // 
            this.test2ScoreLB.AutoSize = true;
            this.test2ScoreLB.Location = new System.Drawing.Point(22, 84);
            this.test2ScoreLB.Name = "test2ScoreLB";
            this.test2ScoreLB.Size = new System.Drawing.Size(75, 13);
            this.test2ScoreLB.TabIndex = 5;
            this.test2ScoreLB.Text = "Test Score #2";
            // 
            // test3ScoreLB
            // 
            this.test3ScoreLB.AutoSize = true;
            this.test3ScoreLB.Location = new System.Drawing.Point(22, 126);
            this.test3ScoreLB.Name = "test3ScoreLB";
            this.test3ScoreLB.Size = new System.Drawing.Size(75, 13);
            this.test3ScoreLB.TabIndex = 6;
            this.test3ScoreLB.Text = "Test Score #3";
            // 
            // averageLB
            // 
            this.averageLB.AutoSize = true;
            this.averageLB.Location = new System.Drawing.Point(22, 168);
            this.averageLB.Name = "averageLB";
            this.averageLB.Size = new System.Drawing.Size(47, 13);
            this.averageLB.TabIndex = 7;
            this.averageLB.Text = "Average";
            // 
            // outAverageLabel
            // 
            this.outAverageLabel.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.outAverageLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outAverageLabel.Location = new System.Drawing.Point(190, 167);
            this.outAverageLabel.Name = "outAverageLabel";
            this.outAverageLabel.Size = new System.Drawing.Size(100, 23);
            this.outAverageLabel.TabIndex = 3;
            // 
            // test1TextBox
            // 
            this.test1TextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.test1TextBox.Location = new System.Drawing.Point(190, 39);
            this.test1TextBox.Name = "test1TextBox";
            this.test1TextBox.Size = new System.Drawing.Size(100, 20);
            this.test1TextBox.TabIndex = 0;
            // 
            // test2TextBox
            // 
            this.test2TextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.test2TextBox.Location = new System.Drawing.Point(190, 81);
            this.test2TextBox.Name = "test2TextBox";
            this.test2TextBox.Size = new System.Drawing.Size(100, 20);
            this.test2TextBox.TabIndex = 1;
            // 
            // test3TextBox
            // 
            this.test3TextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.test3TextBox.Location = new System.Drawing.Point(190, 123);
            this.test3TextBox.Name = "test3TextBox";
            this.test3TextBox.Size = new System.Drawing.Size(100, 20);
            this.test3TextBox.TabIndex = 2;
            this.test3TextBox.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(30, 258);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(169, 52);
            this.calculateBTN.TabIndex = 2;
            this.calculateBTN.Text = "Calculate Average";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(220, 258);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(135, 23);
            this.clearBTN.TabIndex = 3;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(220, 287);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(135, 23);
            this.exitBTN.TabIndex = 4;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // TestScoreAverage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 355);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.TestScoreGB);
            this.Name = "TestScoreAverage";
            this.Text = "Test Score Average";
            this.Load += new System.EventHandler(this.TestScoreAverage_Load);
            this.TestScoreGB.ResumeLayout(false);
            this.TestScoreGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label test1ScoreLB;
        private System.Windows.Forms.GroupBox TestScoreGB;
        private System.Windows.Forms.TextBox test3TextBox;
        private System.Windows.Forms.TextBox test2TextBox;
        private System.Windows.Forms.TextBox test1TextBox;
        private System.Windows.Forms.Label outAverageLabel;
        private System.Windows.Forms.Label averageLB;
        private System.Windows.Forms.Label test3ScoreLB;
        private System.Windows.Forms.Label test2ScoreLB;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

