﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapterFourTutorial4_5
{
    public partial class ColorTheme : Form
    {
        public ColorTheme()
        {
            InitializeComponent();
        }

        private void yellowRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (yellowRadioButton.Checked)
            {
                this.BackColor = Color.Yellow;
            }
        }

        private void RedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (RedRadioButton.Checked)
            {
                this.BackColor = Color.IndianRed;
            }
        }

        private void whiteRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (whiteRadioButton.Checked)
            {
                this.BackColor = Color.White;
            }
        }

        private void NormalRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (NormalRadioButton.Checked)
            {
                this.BackColor = SystemColors.Control;
            }
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
