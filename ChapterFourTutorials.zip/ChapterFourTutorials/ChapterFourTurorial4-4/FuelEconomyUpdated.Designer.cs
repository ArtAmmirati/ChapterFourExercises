﻿namespace ChapterFourTurorial4_4
{
    partial class FuelEconomyUpdated
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inMilesTB = new System.Windows.Forms.TextBox();
            this.inGallonsTB = new System.Windows.Forms.TextBox();
            this.milesDrivenLB = new System.Windows.Forms.Label();
            this.gallonsLB = new System.Windows.Forms.Label();
            this.MPGLabel = new System.Windows.Forms.Label();
            this.outMpgLabel = new System.Windows.Forms.Label();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inMilesTB
            // 
            this.inMilesTB.Location = new System.Drawing.Point(204, 38);
            this.inMilesTB.Name = "inMilesTB";
            this.inMilesTB.Size = new System.Drawing.Size(100, 20);
            this.inMilesTB.TabIndex = 0;
            // 
            // inGallonsTB
            // 
            this.inGallonsTB.Location = new System.Drawing.Point(204, 92);
            this.inGallonsTB.Name = "inGallonsTB";
            this.inGallonsTB.Size = new System.Drawing.Size(100, 20);
            this.inGallonsTB.TabIndex = 1;
            // 
            // milesDrivenLB
            // 
            this.milesDrivenLB.AutoSize = true;
            this.milesDrivenLB.Location = new System.Drawing.Point(12, 41);
            this.milesDrivenLB.Name = "milesDrivenLB";
            this.milesDrivenLB.Size = new System.Drawing.Size(161, 13);
            this.milesDrivenLB.TabIndex = 2;
            this.milesDrivenLB.Text = "Enter the number of miles driven:";
            // 
            // gallonsLB
            // 
            this.gallonsLB.AutoSize = true;
            this.gallonsLB.Location = new System.Drawing.Point(12, 95);
            this.gallonsLB.Name = "gallonsLB";
            this.gallonsLB.Size = new System.Drawing.Size(147, 13);
            this.gallonsLB.TabIndex = 3;
            this.gallonsLB.Text = "Enter the gallons of gas used:";
            // 
            // MPGLabel
            // 
            this.MPGLabel.AutoSize = true;
            this.MPGLabel.Location = new System.Drawing.Point(12, 150);
            this.MPGLabel.Name = "MPGLabel";
            this.MPGLabel.Size = new System.Drawing.Size(84, 13);
            this.MPGLabel.TabIndex = 4;
            this.MPGLabel.Text = "Your car\'s MPG:";
            // 
            // outMpgLabel
            // 
            this.outMpgLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outMpgLabel.Location = new System.Drawing.Point(204, 149);
            this.outMpgLabel.Name = "outMpgLabel";
            this.outMpgLabel.Size = new System.Drawing.Size(100, 23);
            this.outMpgLabel.TabIndex = 5;
            this.outMpgLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(15, 206);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(128, 37);
            this.calculateBTN.TabIndex = 6;
            this.calculateBTN.Text = "Calculate MPG";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(188, 206);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(116, 37);
            this.exitBTN.TabIndex = 7;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // FuelEconomyUpdated
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 266);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.outMpgLabel);
            this.Controls.Add(this.MPGLabel);
            this.Controls.Add(this.gallonsLB);
            this.Controls.Add(this.milesDrivenLB);
            this.Controls.Add(this.inGallonsTB);
            this.Controls.Add(this.inMilesTB);
            this.Name = "FuelEconomyUpdated";
            this.Text = "Fuel Economy Updated";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inMilesTB;
        private System.Windows.Forms.TextBox inGallonsTB;
        private System.Windows.Forms.Label milesDrivenLB;
        private System.Windows.Forms.Label gallonsLB;
        private System.Windows.Forms.Label MPGLabel;
        private System.Windows.Forms.Label outMpgLabel;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

