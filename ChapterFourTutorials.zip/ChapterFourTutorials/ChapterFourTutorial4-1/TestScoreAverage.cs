﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapterFourTutorial4_1
{
    public partial class TestScoreAverage : Form
    {
        public TestScoreAverage()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {
                const double HIGH_SCORE = 95.0;         //High Score Value
                double test1, test2, test3, average;    //Variablese

                // Get the test scores from the Textboxes
                test1 = double.Parse(test1TextBox.Text);
                test2 = double.Parse(test2TextBox.Text);
                test3 = double.Parse(test3TextBox.Text);

                //Calculate the average test score
                average = (test1 + test2 + test3) / 3;

                //Display the average, rounded to 2 decimal places.
                outAverageLabel.Text = average.ToString("n1");

                // If the average is a high score, congratulate
                //the user with a message box.
                if (average > HIGH_SCORE)
                {
                    MessageBox.Show("Congratulations ! Great Job !");
                }
            }
            catch(Exception ex)
            {
                    // display the default error message.
                    MessageBox.Show (ex.Message);
               
            }
                 

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // Clear the textboxes and averge label controls
            test1TextBox.Text = "";
            test2TextBox.Text = "";
            test3TextBox.Text = "";
            outAverageLabel.Text = "";

           //reset focus to test 1
            test1TextBox.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            //close this form
            this.Close();
        }

        private void TestScoreAverage_Load(object sender, EventArgs e)
        {

        }
    }
}
