﻿namespace ChapterFourTutorial4_2
{
    partial class PayrollwithOvertime
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.hoursWorkedlabel = new System.Windows.Forms.Label();
            this.hourlyPayRatelabel = new System.Windows.Forms.Label();
            this.grossPaylabel = new System.Windows.Forms.Label();
            this.outGrossPaylabel = new System.Windows.Forms.Label();
            this.hoursWorkedTB = new System.Windows.Forms.TextBox();
            this.hourlyPayRateTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // calculateBTN
            // 
            this.calculateBTN.Location = new System.Drawing.Point(14, 207);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(88, 52);
            this.calculateBTN.TabIndex = 0;
            this.calculateBTN.Text = "Calculate Gross Pay";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(124, 207);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(88, 52);
            this.clearBTN.TabIndex = 1;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(234, 207);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(88, 52);
            this.exitBTN.TabIndex = 2;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // hoursWorkedlabel
            // 
            this.hoursWorkedlabel.AutoSize = true;
            this.hoursWorkedlabel.Location = new System.Drawing.Point(11, 26);
            this.hoursWorkedlabel.Name = "hoursWorkedlabel";
            this.hoursWorkedlabel.Size = new System.Drawing.Size(79, 13);
            this.hoursWorkedlabel.TabIndex = 3;
            this.hoursWorkedlabel.Text = "Hours Worked:";
            // 
            // hourlyPayRatelabel
            // 
            this.hourlyPayRatelabel.AutoSize = true;
            this.hourlyPayRatelabel.Location = new System.Drawing.Point(12, 91);
            this.hourlyPayRatelabel.Name = "hourlyPayRatelabel";
            this.hourlyPayRatelabel.Size = new System.Drawing.Size(87, 13);
            this.hourlyPayRatelabel.TabIndex = 4;
            this.hourlyPayRatelabel.Text = "Hourly Pay Rate:";
            // 
            // grossPaylabel
            // 
            this.grossPaylabel.AutoSize = true;
            this.grossPaylabel.Location = new System.Drawing.Point(12, 156);
            this.grossPaylabel.Name = "grossPaylabel";
            this.grossPaylabel.Size = new System.Drawing.Size(58, 13);
            this.grossPaylabel.TabIndex = 5;
            this.grossPaylabel.Text = "Gross Pay:";
            // 
            // outGrossPaylabel
            // 
            this.outGrossPaylabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outGrossPaylabel.Location = new System.Drawing.Point(124, 155);
            this.outGrossPaylabel.Name = "outGrossPaylabel";
            this.outGrossPaylabel.Size = new System.Drawing.Size(198, 23);
            this.outGrossPaylabel.TabIndex = 6;
            this.outGrossPaylabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursWorkedTB
            // 
            this.hoursWorkedTB.Location = new System.Drawing.Point(124, 23);
            this.hoursWorkedTB.Name = "hoursWorkedTB";
            this.hoursWorkedTB.Size = new System.Drawing.Size(198, 20);
            this.hoursWorkedTB.TabIndex = 7;
            this.hoursWorkedTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hourlyPayRateTB
            // 
            this.hourlyPayRateTB.Location = new System.Drawing.Point(124, 88);
            this.hourlyPayRateTB.Name = "hourlyPayRateTB";
            this.hourlyPayRateTB.Size = new System.Drawing.Size(198, 20);
            this.hourlyPayRateTB.TabIndex = 8;
            this.hourlyPayRateTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PayrollwithOvertime
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 285);
            this.Controls.Add(this.hourlyPayRateTB);
            this.Controls.Add(this.hoursWorkedTB);
            this.Controls.Add(this.outGrossPaylabel);
            this.Controls.Add(this.grossPaylabel);
            this.Controls.Add(this.hourlyPayRatelabel);
            this.Controls.Add(this.hoursWorkedlabel);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Name = "PayrollwithOvertime";
            this.Text = "Payroll with Overtime";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Label hoursWorkedlabel;
        private System.Windows.Forms.Label hourlyPayRatelabel;
        private System.Windows.Forms.Label grossPaylabel;
        private System.Windows.Forms.Label outGrossPaylabel;
        private System.Windows.Forms.TextBox hoursWorkedTB;
        private System.Windows.Forms.TextBox hourlyPayRateTB;
    }
}

