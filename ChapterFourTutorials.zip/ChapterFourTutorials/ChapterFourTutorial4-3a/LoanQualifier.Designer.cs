﻿namespace ChapterFourTutorial4_3a
{
    partial class LoanQualifier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.yearsTextBox = new System.Windows.Forms.TextBox();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.currentJobLabel = new System.Windows.Forms.Label();
            this.loanDecisionLabel = new System.Windows.Forms.Label();
            this.decisionLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkBTN
            // 
            this.checkBTN.Location = new System.Drawing.Point(13, 190);
            this.checkBTN.Name = "checkBTN";
            this.checkBTN.Size = new System.Drawing.Size(160, 71);
            this.checkBTN.TabIndex = 2;
            this.checkBTN.Text = "Check Qualifications";
            this.checkBTN.UseVisualStyleBackColor = true;
            this.checkBTN.Click += new System.EventHandler(this.checkBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(193, 228);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(78, 33);
            this.exitBTN.TabIndex = 4;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(193, 190);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(78, 32);
            this.clearBTN.TabIndex = 3;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Location = new System.Drawing.Point(164, 12);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.salaryTextBox.TabIndex = 0;
            // 
            // yearsTextBox
            // 
            this.yearsTextBox.Location = new System.Drawing.Point(164, 47);
            this.yearsTextBox.Name = "yearsTextBox";
            this.yearsTextBox.Size = new System.Drawing.Size(100, 20);
            this.yearsTextBox.TabIndex = 1;
            // 
            // salaryLabel
            // 
            this.salaryLabel.AutoSize = true;
            this.salaryLabel.Location = new System.Drawing.Point(12, 19);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(75, 13);
            this.salaryLabel.TabIndex = 5;
            this.salaryLabel.Text = "Annual Salary:";
            // 
            // currentJobLabel
            // 
            this.currentJobLabel.AutoSize = true;
            this.currentJobLabel.Location = new System.Drawing.Point(12, 55);
            this.currentJobLabel.Name = "currentJobLabel";
            this.currentJobLabel.Size = new System.Drawing.Size(105, 13);
            this.currentJobLabel.TabIndex = 6;
            this.currentJobLabel.Text = "Years at current Job:";
            // 
            // loanDecisionLabel
            // 
            this.loanDecisionLabel.AutoSize = true;
            this.loanDecisionLabel.Location = new System.Drawing.Point(10, 96);
            this.loanDecisionLabel.Name = "loanDecisionLabel";
            this.loanDecisionLabel.Size = new System.Drawing.Size(75, 13);
            this.loanDecisionLabel.TabIndex = 7;
            this.loanDecisionLabel.Text = "Loan Decision";
            // 
            // decisionLabel
            // 
            this.decisionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.decisionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decisionLabel.Location = new System.Drawing.Point(22, 123);
            this.decisionLabel.Name = "decisionLabel";
            this.decisionLabel.Size = new System.Drawing.Size(249, 50);
            this.decisionLabel.TabIndex = 8;
            this.decisionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoanQualifier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 288);
            this.Controls.Add(this.decisionLabel);
            this.Controls.Add(this.loanDecisionLabel);
            this.Controls.Add(this.currentJobLabel);
            this.Controls.Add(this.salaryLabel);
            this.Controls.Add(this.yearsTextBox);
            this.Controls.Add(this.salaryTextBox);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.checkBTN);
            this.Name = "LoanQualifier";
            this.Text = "Loan Qualifier";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.TextBox yearsTextBox;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Label currentJobLabel;
        private System.Windows.Forms.Label loanDecisionLabel;
        private System.Windows.Forms.Label decisionLabel;
    }
}

