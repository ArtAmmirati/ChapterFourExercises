﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapterFourTutorial4_3a
{
    public partial class LoanQualifier : Form
    {
        public LoanQualifier()
        {
            InitializeComponent();
        }

        private void checkBTN_Click(object sender, EventArgs e)
        {
            try
            {
                // names constant
                const decimal MINIMUM_SALARY = 40000m;
                const int MINIMUM_YEARS_ON_JOB = 2;
                //local variables
                decimal salary;
                int yearsOnJob;
                //get salary and years on the job
                salary = decimal.Parse(salaryTextBox.Text);
                yearsOnJob = int.Parse(yearsTextBox.Text);
                //determine qhether the user qualifies
                if (salary >= MINIMUM_SALARY)
                {
                    if (yearsOnJob >= MINIMUM_YEARS_ON_JOB)
                    {
                        //the user qualifies
                        decisionLabel.Text = "You qualify for the Loan";

                    }
                    else
                    {
                        //the user does not qualify
                        decisionLabel.Text = "Minimum years at current" + " " + "Job not met";
                    }

                }
                else
                {
                    //the user does not qualify
                    decisionLabel.Text = "Minimum Salary Requirement" + " " + "not met.";
                }
            }
            catch (Exception ex)
           
            {
                //display an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            salaryTextBox.Text = "";
            yearsTextBox.Text = "";
            decisionLabel.Text = "";

            salaryTextBox.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
